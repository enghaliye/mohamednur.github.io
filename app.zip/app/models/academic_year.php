<?php
class academic_year extends Eloquent {
	public $timestamps = false;
	protected $table = 'academic_year';
}
