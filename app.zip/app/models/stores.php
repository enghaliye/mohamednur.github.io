<?php
class stores extends Eloquent {
	public $timestamps = false;
	protected $table = "stores";
}