<?php
class roles extends Eloquent {
	public $timestamps = false;
	protected $table = "roles";
}