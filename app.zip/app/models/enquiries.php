<?php
class enquiries extends Eloquent {
	public $timestamps = false;
	protected $table = "enquiries";
}