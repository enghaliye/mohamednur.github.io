<?php
class messages_list extends Eloquent {
	public $timestamps = false;
	protected $table = 'messages_list';
}
