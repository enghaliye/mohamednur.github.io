<?php
class hostel extends Eloquent {
	public $timestamps = false;
	protected $table = 'hostel';
}
