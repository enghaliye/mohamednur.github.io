<?php
class student_categories extends Eloquent {
	public $timestamps = false;
	protected $table = "student_categories";
}