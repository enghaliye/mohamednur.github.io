<?php
class id_cards extends Eloquent {
	public $timestamps = false;
	protected $table = 'id_cards';
}
