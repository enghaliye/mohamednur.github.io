<?php
class static_pages extends Eloquent {
	public $timestamps = false;
	protected $table = 'static_pages';
}
