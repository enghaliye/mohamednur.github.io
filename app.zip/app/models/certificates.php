<?php
class certificates extends Eloquent {
	public $timestamps = false;
	protected $table = 'certificates';
}
