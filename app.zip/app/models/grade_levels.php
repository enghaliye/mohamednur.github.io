<?php
class grade_levels extends Eloquent {
	public $timestamps = false;
	protected $table = 'grade_levels';
}
