<?php
class mob_notifications extends Eloquent {
	public $timestamps = false;
	protected $table = 'mob_notifications';
}
