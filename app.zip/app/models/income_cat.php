<?php
class income_cat extends Eloquent {
	public $timestamps = false;
	protected $table = 'income_cat';
}
