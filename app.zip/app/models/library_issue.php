<?php
class library_issue extends Eloquent {
	public $timestamps = false;
	protected $table = "library_issue";
}