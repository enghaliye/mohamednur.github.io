<?php
class fee_discount extends Eloquent {
	public $timestamps = false;
	protected $table = 'fee_discount';
}
