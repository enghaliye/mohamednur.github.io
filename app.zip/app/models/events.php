<?php
class events extends Eloquent {
	public $timestamps = false;
	protected $table = 'events';
}