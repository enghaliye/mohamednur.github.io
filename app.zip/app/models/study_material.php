<?php
class study_material extends Eloquent {
	public $timestamps = false;
	protected $table = 'study_material';
}
