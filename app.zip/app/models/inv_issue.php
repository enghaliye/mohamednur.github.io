<?php
class inv_issue extends Eloquent {
	public $timestamps = false;
	protected $table = "inv_issue";
}