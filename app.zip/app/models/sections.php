<?php
class sections extends Eloquent {
	public $timestamps = false;
	protected $table = 'sections';
}
