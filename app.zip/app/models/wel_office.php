<?php
class wel_office extends Eloquent {
	public $timestamps = false;
	protected $table = "wel_office";
}