<?php
class postal extends Eloquent {
	public $timestamps = false;
	protected $table = "postal";
}