<?php
class transport_vehicles extends Eloquent {
	public $timestamps = false;
	protected $table = "transport_vehicles";
}