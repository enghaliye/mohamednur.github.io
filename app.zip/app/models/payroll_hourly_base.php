<?php
class payroll_hourly_base extends Eloquent {
	public $timestamps = false;
	protected $table = 'payroll_hourly_base';
}