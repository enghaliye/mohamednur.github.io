<?php
class inv_cat extends Eloquent {
	public $timestamps = false;
	protected $table = "inv_cat";
}