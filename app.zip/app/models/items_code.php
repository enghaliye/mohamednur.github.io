<?php
class items_code extends Eloquent {
	public $timestamps = false;
	protected $table = "items_code";
}