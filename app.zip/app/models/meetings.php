<?php
class meetings extends Eloquent {
	public $timestamps = false;
	protected $table = 'meetings';
}