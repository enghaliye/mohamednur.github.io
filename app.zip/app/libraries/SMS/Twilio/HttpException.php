<?php

class Services_Twilio_HttpException extends ErrorException {}